export type SiteConfig = typeof siteConfig;

export const siteConfig = {
	name: "PT Senara Stratava Pilar Mandiri",
	description:
		"Konsultan Profesional untuk Asuransi, Sertifikasi, dan Legalitas Usaha Anda.",
};
